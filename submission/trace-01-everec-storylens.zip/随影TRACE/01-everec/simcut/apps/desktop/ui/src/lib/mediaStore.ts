import { guessKind, guessMime } from "./mime";
import { cachePreviewUrl, getCachedUrl, setCachedUrl } from "./previewCache";

const DB_NAME = "simcut-media";
const STORE = "blobs";
const DB_VERSION = 2;

interface StoredMedia {
  mimeType: string;
  buffer: ArrayBuffer;
  fileName?: string;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE);
      }
    };
  });
}

export async function saveBlob(id: string, file: File | Blob, fileName?: string): Promise<void> {
  const mimeType =
    file.type || guessMime(fileName ?? (file instanceof File ? file.name : "media.mp4"));
  const buffer = (await file.arrayBuffer()).slice(0);
  cachePreviewUrl(id, new Blob([buffer], { type: mimeType }));
  const entry: StoredMedia = { mimeType, buffer, fileName: fileName ?? (file instanceof File ? file.name : undefined) };
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(entry, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function readEntry(id: string): Promise<StoredMedia | null> {
  const db = await openDb();
  const raw = await new Promise<StoredMedia | Blob | null>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => resolve(req.result ?? null);
    req.onerror = () => reject(req.error);
  });

  if (!raw) return null;

  // 兼容旧版：直接存的 Blob/File
  if (raw instanceof Blob) {
    const mimeType = raw.type || "application/octet-stream";
    const buffer = (await raw.arrayBuffer()).slice(0);
    return { mimeType, buffer };
  }

  if ("buffer" in raw && "mimeType" in raw) {
    const entry = raw as StoredMedia;
    return {
      mimeType: entry.mimeType,
      buffer: entry.buffer.slice(0),
    };
  }

  return null;
}

export async function getBlob(id: string): Promise<Blob | null> {
  const entry = await readEntry(id);
  if (!entry) return null;
  const mime =
    entry.mimeType && entry.mimeType !== "application/octet-stream"
      ? entry.mimeType
      : guessMime(entry.fileName ?? "media.bin");
  return new Blob([entry.buffer.slice(0)], { type: mime });
}

export async function getObjectUrl(id: string): Promise<string | null> {
  const cached = getCachedUrl(id);
  if (cached) return cached;
  const blob = await getBlob(id);
  if (!blob) return null;
  const url = URL.createObjectURL(blob);
  setCachedUrl(id, url);
  return url;
}

export function getObjectUrlSync(id: string): string | null {
  return getCachedUrl(id);
}

export function probeVideo(file: File, blobUrl?: string): Promise<{
  durationMs: number;
  width: number;
  height: number;
}> {
  return new Promise((resolve, reject) => {
    const url = blobUrl ?? URL.createObjectURL(file);
    const shouldRevoke = !blobUrl;
    const video = document.createElement("video");
    video.preload = "auto";
    video.muted = true;
    video.playsInline = true;

    const cleanup = () => {
      if (shouldRevoke) URL.revokeObjectURL(url);
    };

    video.onloadeddata = () => {
      resolve({
        durationMs: Math.round((video.duration || 0) * 1000),
        width: video.videoWidth || 1920,
        height: video.videoHeight || 1080,
      });
      cleanup();
    };
    video.onerror = () => {
      cleanup();
      reject(new Error(`无法解码视频（${file.name}）。若为 HEVC/H.265，请尝试导出为 H.264 MP4`));
    };
    video.src = url;
    video.load();
  });
}

export function probeImage(file: File, blobUrl?: string): Promise<{
  durationMs: number;
  width: number;
  height: number;
}> {
  return new Promise((resolve, reject) => {
    const url = blobUrl ?? URL.createObjectURL(file);
    const shouldRevoke = !blobUrl;
    const img = new Image();
    img.onload = () => {
      resolve({
        durationMs: 5000,
        width: img.naturalWidth,
        height: img.naturalHeight,
      });
      if (shouldRevoke) URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      if (shouldRevoke) URL.revokeObjectURL(url);
      reject(new Error(`无法加载图片: ${file.name}`));
    };
    img.src = url;
  });
}

export async function probeMedia(file: File): Promise<{
  durationMs: number;
  width: number;
  height: number;
  kind: "video" | "image" | "audio";
}> {
  const mime = file.type || guessMime(file.name);
  const kind = guessKind(file.name, mime);
  if (kind === "audio") {
    const meta = await probeAudio(file);
    return { ...meta, kind: "audio" };
  }
  if (kind === "image") {
    const meta = await probeImage(file);
    return { ...meta, kind: "image" };
  }
  const meta = await probeVideo(file);
  return { ...meta, kind: "video" };
}

async function probeAudio(file: File): Promise<{
  durationMs: number;
  width: number;
  height: number;
}> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const audio = document.createElement("audio");
    audio.preload = "metadata";
    audio.onloadedmetadata = () => {
      const durationMs = Number.isFinite(audio.duration)
        ? Math.round(audio.duration * 1000)
        : 0;
      URL.revokeObjectURL(url);
      resolve({ durationMs, width: 0, height: 0 });
    };
    audio.onerror = () => {
      URL.revokeObjectURL(url);
      resolve({ durationMs: 0, width: 0, height: 0 });
    };
    audio.src = url;
  });
}

export async function captureVideoFrame(
  blobId: string,
  timeMs: number,
): Promise<{ r: number; g: number; b: number }[]> {
  const url = await getObjectUrl(blobId);
  if (!url) throw new Error("素材未找到");

  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";

    video.onloadeddata = () => {
      video.currentTime = Math.min(timeMs / 1000, Math.max(0, video.duration - 0.1));
    };

    video.onseeked = () => {
      const canvas = document.createElement("canvas");
      canvas.width = Math.min(video.videoWidth, 320);
      canvas.height = Math.min(video.videoHeight, 180);
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        URL.revokeObjectURL(url);
        reject(new Error("Canvas 不可用"));
        return;
      }
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      const pixels: { r: number; g: number; b: number }[] = [];
      for (let i = 0; i < data.length; i += 4) {
        pixels.push({ r: data[i], g: data[i + 1], b: data[i + 2] });
      }
      URL.revokeObjectURL(url);
      resolve(pixels);
    };

    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("无法截取视频帧"));
    };

    video.src = url;
    video.load();
  });
}
