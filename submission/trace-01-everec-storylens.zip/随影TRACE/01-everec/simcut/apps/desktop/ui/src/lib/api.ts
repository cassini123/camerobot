import { convertFileSrc } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";
import type {
  AiAnalysisResult,
  ColorAnalysisResult,
  EffectPreset,
  ExportOptions,
  ExportResult,
  MediaAsset,
  Project,
  ProjectSummary,
  StillFrame,
  SubtitleCue,
} from "../types";
import { DEFAULT_EFFECT_PRESETS } from "./effectPresets";
import { analyzeImageFile, analyzeWaveformMatch } from "./colorAnalysis";
import { guessMime, guessKind } from "./mime";
import { cachePreviewUrl } from "./previewCache";
import * as mediaStore from "./mediaStore";
import { addClipToTrack, migrateProject, removeClip, updateClip } from "./timelineEdit";
import * as projectStore from "./projectStore";
import { DESKTOP_APP_HINT, invoke, isTauriApp } from "./tauri";

function requireDesktop<T>(fn: () => Promise<T>): Promise<T> {
  if (!isTauriApp()) return Promise.reject(new Error(DESKTOP_APP_HINT));
  return fn();
}

const MEDIA_FILTERS = [
  {
    name: "媒体文件",
    extensions: [
      "mp4", "mov", "m4v", "webm", "mkv", "avi",
      "jpg", "jpeg", "png", "webp", "gif",
      "mp3", "wav", "m4a", "aac",
    ],
  },
];

function generateSubtitles(language: string, mediaId?: string): SubtitleCue[] {
  const langLabel =
    { zh: "中文", en: "English", ja: "日本語", ko: "한국어" }[language] ?? language;
  const samples: Record<string, [string, number, number][]> = {
    en: [
      ["Welcome to Simcut", 0, 2000],
      ["Lightweight editing for short-form", 2000, 4500],
      ["Export and share instantly", 4500, 7000],
    ],
    ja: [
      ["Simcutへようこそ", 0, 2000],
      ["短編向けの軽量編集", 2000, 4500],
      ["すぐに書き出して共有", 4500, 7000],
    ],
    ko: [
      ["Simcut에 오신 것을 환영합니다", 0, 2000],
      ["숏폼을 위한 경량 편집", 2000, 4500],
      ["바로보내고 공유하세요", 4500, 7000],
    ],
    zh: [
      ["欢迎使用 Simcut", 0, 2000],
      ["超短篇轻量剪辑工具", 2000, 4500],
      ["导出渲染，一键交付", 4500, 7000],
    ],
  };
  const lines = samples[language] ?? samples.zh;
  return lines.map(([text, start, end]) => ({
    id: crypto.randomUUID(),
    startMs: start,
    endMs: end,
    text: `[${langLabel}] ${text}`,
    language,
    mediaId,
  }));
}

export const api = {
  isDesktop: isTauriApp,

  listProjects: (): Promise<ProjectSummary[]> =>
    isTauriApp()
      ? invoke("list_projects")
      : Promise.resolve(projectStore.listProjects()),

  createProject: (name: string): Promise<Project> =>
    isTauriApp()
      ? invoke("create_project", { name })
      : Promise.resolve(projectStore.createProject(name)),

  loadProject: (id: string): Promise<Project> =>
    isTauriApp()
      ? invoke("load_project", { id }).then((p) => migrateProject(p as Project))
      : Promise.resolve(projectStore.loadProject(id)),

  saveProject: (project: Project): Promise<void> =>
    isTauriApp()
      ? invoke("save_project", { project })
      : Promise.resolve(projectStore.saveProject(project)),

  importMediaFile: async (
    project: Project,
    file: File,
    tags?: string[],
  ): Promise<{ project: Project; asset: MediaAsset }> => {
    if (isTauriApp()) {
      throw new Error("桌面端请使用 pickAndImportMedia");
    }

    const id = crypto.randomUUID();
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "mp4";
    const mimeType = file.type || guessMime(file.name);
    const blob = file.type
      ? file
      : new File([file], file.name, { type: mimeType });
    cachePreviewUrl(id, blob);
    await mediaStore.saveBlob(id, blob, file.name);

    const meta = await mediaStore.probeMedia(file);
    const kind = meta.kind ?? guessKind(file.name, mimeType);

    const asset: MediaAsset = {
      id,
      name: file.name.replace(/\.[^.]+$/, ""),
      fileName: file.name,
      format: ext,
      durationMs: meta.durationMs,
      width: meta.width,
      height: meta.height,
      tags: tags ?? [],
      createdAt: String(Math.floor(Date.now() / 1000)),
      blobId: id,
      mimeType,
      kind,
    };

    const isImage = kind === "image";
    const isAudio = kind === "audio";
    const clipDuration = isImage ? 5000 : meta.durationMs || 5000;
    const trackIndex = isAudio ? 1 : 0;
    const clip = {
      id: crypto.randomUUID(),
      trackIndex,
      mediaId: id,
      startMs: 0,
      durationMs: clipDuration,
      trimInMs: 0,
      trimOutMs: clipDuration,
      effectIds: [] as string[],
    };

    let updated: Project = {
      ...project,
      media: [...project.media, asset],
      durationMs: Math.max(project.durationMs, meta.durationMs),
      resolution: meta.width > 0 ? [meta.width, meta.height] : project.resolution,
    };
    updated = projectStore.addClip(updated, clip);
    return { project: updated, asset };
  },

  pickAndImportMedia: async (project: Project): Promise<Project> => {
    const selected = await open({
      multiple: true,
      filters: MEDIA_FILTERS,
    });
    if (!selected) return project;

    const paths = Array.isArray(selected) ? selected : [selected];
    let current = project;
    for (const sourcePath of paths) {
      await invoke("import_media", {
        projectId: current.id,
        sourcePath,
        name: null,
        tags: [],
      });
      current = await api.loadProject(current.id);
    }
    return current;
  },

  getMediaUrl: async (asset: MediaAsset): Promise<string | null> => {
    if (isTauriApp()) {
      try {
        const path = await invoke<string>("get_media_path", { fileName: asset.fileName });
        return convertFileSrc(path);
      } catch {
        return null;
      }
    }
    const blobId = asset.blobId ?? asset.id;
    const sync = mediaStore.getObjectUrlSync(blobId);
    if (sync) return sync;
    return mediaStore.getObjectUrl(blobId);
  },

  updateClip: (project: Project, clipId: string, patch: Parameters<typeof updateClip>[2]) =>
    Promise.resolve(updateClip(project, clipId, patch)),

  addClipToTrack: (
    project: Project,
    mediaId: string,
    trackIndex: number,
    startMs: number,
  ): Promise<Project> => {
    const media = project.media.find((m) => m.id === mediaId);
    if (!media) return Promise.reject(new Error("素材不存在"));
    return Promise.resolve(addClipToTrack(project, media, trackIndex, startMs));
  },

  removeClip: (project: Project, clipId: string): Promise<Project> =>
    Promise.resolve(removeClip(project, clipId)),

  importMedia: (
    projectId: string,
    sourcePath: string,
    name?: string,
    tags?: string[],
  ): Promise<MediaAsset> =>
    requireDesktop(() =>
      invoke("import_media", { projectId, sourcePath, name, tags }),
    ),

  listEffectPresets: (): Promise<EffectPreset[]> =>
    isTauriApp()
      ? invoke("list_effect_presets")
      : Promise.resolve(DEFAULT_EFFECT_PRESETS),

  addStillFrame: (
    projectId: string,
    mediaId: string,
    timestampMs: number,
    label: string,
    tags: string[],
    colorPalette: string[],
    thumbnail?: string,
  ): Promise<StillFrame> => {
    if (isTauriApp()) {
      return invoke("add_still_frame", {
        projectId,
        mediaId,
        timestampMs,
        label,
        tags,
        colorPalette,
        thumbnail,
      });
    }
    const project = projectStore.loadProject(projectId);
    const still: StillFrame = {
      id: crypto.randomUUID(),
      mediaId,
      timestampMs,
      label,
      tags,
      colorPalette,
      thumbnail,
    };
    projectStore.addStill(project, still);
    return Promise.resolve(still);
  },

  analyzeColorFromFile: (file: File): Promise<ColorAnalysisResult> =>
    analyzeImageFile(file),

  analyzeColorWithFrame: async (
    referenceFile: File,
    blobId?: string,
    timeMs = 0,
  ): Promise<ColorAnalysisResult> => {
    if (blobId) {
      const sourcePixels = await mediaStore.captureVideoFrame(blobId, timeMs);
      return analyzeWaveformMatch(referenceFile, sourcePixels);
    }
    return analyzeImageFile(referenceFile);
  },

  analyzeColorFromPhoto: (sourcePath: string): Promise<ColorAnalysisResult> =>
    requireDesktop(() => invoke("analyze_color_from_photo", { sourcePath })),

  saveLutPreset: (lutCube: string, name: string): Promise<string> => {
    if (isTauriApp()) {
      return invoke("save_lut_preset", { lutCube, name });
    }
    const key = `simcut-lut-${name.replace(/\s+/g, "_")}`;
    localStorage.setItem(key, lutCube);
    return Promise.resolve(key);
  },

  recognizeSubtitles: (
    projectId: string,
    language: string,
    mediaId?: string,
  ): Promise<SubtitleCue[]> => {
    if (isTauriApp()) {
      return invoke("recognize_subtitles", { projectId, language, mediaId });
    }
    const cues = generateSubtitles(language, mediaId);
    const project = projectStore.loadProject(projectId);
    projectStore.addSubtitles(project, cues);
    return Promise.resolve(cues);
  },

  addSubtitle: (project: Project, cue: Omit<SubtitleCue, "id">): Promise<Project> => {
    const newCue: SubtitleCue = { ...cue, id: crypto.randomUUID() };
    return Promise.resolve({
      ...project,
      subtitles: [...project.subtitles, newCue],
    });
  },

  updateSubtitle: (
    project: Project,
    cueId: string,
    patch: Partial<Pick<SubtitleCue, "text" | "startMs" | "endMs" | "language">>,
  ): Promise<Project> =>
    Promise.resolve({
      ...project,
      subtitles: project.subtitles.map((c) =>
        c.id === cueId ? { ...c, ...patch } : c,
      ),
    }),

  removeSubtitle: (project: Project, cueId: string): Promise<Project> =>
    Promise.resolve({
      ...project,
      subtitles: project.subtitles.filter((c) => c.id !== cueId),
    }),

  analyzeFrameAi: (description: string, frameIndex: number): Promise<AiAnalysisResult> =>
    isTauriApp()
      ? invoke("analyze_frame_ai", { description, frameIndex })
      : Promise.resolve(mockAiAnalysis(description)),

  applyPromptEdit: (prompt: string): Promise<string> =>
    isTauriApp()
      ? invoke("apply_prompt_edit_command", { prompt })
      : Promise.resolve(applyPromptLocal(prompt)),

  exportProject: (
    projectId: string,
    options: ExportOptions,
  ): Promise<ExportResult> => {
    if (isTauriApp()) {
      return invoke("export_project", { projectId, options });
    }
    return exportProjectWeb(projectId, options);
  },

  openExportFolder: (outputPath: string): Promise<void> =>
    requireDesktop(() => invoke("open_export_folder", { outputPath })),

  getProjectsDir: (): Promise<string> =>
    requireDesktop(() => invoke("get_projects_dir")),

  getExportsDir: (): Promise<string> =>
    requireDesktop(() => invoke("get_exports_dir")),
};

function applyPromptLocal(prompt: string): string {
  const lower = prompt.toLowerCase();
  if (lower.includes("渐显") || lower.includes("fade in")) return "已应用渐显特效（500ms）";
  if (lower.includes("渐隐") || lower.includes("fade out")) return "已应用渐隐特效（500ms）";
  if (lower.includes("高亮") || lower.includes("highlight")) return "已应用高亮强调特效";
  if (lower.includes("剪短") || lower.includes("trim")) return "已根据 Prompt 裁剪片段";
  if (lower.includes("lut") || lower.includes("色彩") || lower.includes("color")) return "已应用自适应 LUT";
  if (lower.includes("字幕") || lower.includes("subtitle")) return "已生成多语言字幕轨道";
  return `已解析 Prompt「${prompt}」并加入编辑队列`;
}

async function exportProjectWeb(
  projectId: string,
  options: ExportOptions,
): Promise<ExportResult> {
  const project = projectStore.loadProject(projectId);
  const payload = {
    project,
    options,
    exportedAt: new Date().toISOString(),
    hint: "网页端导出项目包。完整 FFmpeg 渲染请使用桌面端 App。",
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${project.name}-simcut-export.json`;
  a.click();
  URL.revokeObjectURL(url);

  const msgs = [`项目包已下载: ${project.name}-simcut-export.json`];
  if (options.saveToPhotos) msgs.push("相册保存需桌面端完成渲染后自动导入");
  if (options.uploadCloud) msgs.push(`网盘上传（${options.cloudProvider ?? "默认"}）需桌面端执行`);

  const filename = `${project.name}-simcut-export.json`;
  return {
    success: true,
    outputPath: filename,
    message: msgs.join(" | "),
    savedToPhotos: false,
    uploadedToCloud: false,
  };
}

function mockAiAnalysis(description: string): AiAnalysisResult {
  return {
    metrics: {
      iso: 800,
      shutterSpeed: "1/125",
      aperture: 2.8,
      exposureValue: 0.1,
      whiteBalanceK: 5600,
      highlightClipping: 0.05,
      shadowDetail: 0.72,
    },
    suggestions: [
      "曝光均衡，可直接剪辑",
      description ? `已分析素材描述：${description.slice(0, 40)}` : "",
    ].filter(Boolean),
    promptEdits: [
      { prompt: "让画面更电影感", action: "apply_cinematic_lut", confidence: 0.82 },
      { prompt: "加快节奏剪短前 2 秒", action: "trim_start 2000ms", confidence: 0.91 },
    ],
    overallScore: 0.85,
  };
}

export function formatMs(ms: number): string {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem.toString().padStart(2, "0")}`;
}

export function subtitleAtTime(project: Project, timeMs: number): SubtitleCue | null {
  return (
    project.subtitles.find(
      (c) => timeMs >= c.startMs && timeMs < c.endMs,
    ) ?? null
  );
}
