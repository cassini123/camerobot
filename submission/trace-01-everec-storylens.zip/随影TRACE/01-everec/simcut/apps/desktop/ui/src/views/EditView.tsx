import { useCallback, useEffect, useRef, useState } from "react";
import { Camera, Film, Image, Music, Upload, Video } from "lucide-react";
import { AspectRatioPicker } from "../components/edit/AspectRatioPicker";
import { ResizableSplit } from "../components/edit/ResizableSplit";
import { MediaBin } from "../components/timeline/MediaBin";
import { Timeline } from "../components/timeline/Timeline";
import { api, formatMs, subtitleAtTime } from "../lib/api";
import { isTauriApp } from "../lib/tauri";
import { aspectCssRatio } from "../lib/aspectRatio";
import { capturePreviewFrame } from "../lib/captureFrame";
import { resolvePreviewKind } from "../lib/fonts";
import { extFromName } from "../lib/mime";
import { clipAtTime, findMedia } from "../lib/timelineEdit";
import type { Clip, Project } from "../types";

interface Props {
  project: Project;
  positionMs: number;
  playing: boolean;
  onProjectUpdate: (project: Project) => void;
  onPositionChange: (ms: number) => void;
}

export function EditView({
  project,
  positionMs,
  playing,
  onProjectUpdate,
  onPositionChange,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewKind, setPreviewKind] = useState<"video" | "image" | "audio" | null>(null);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [selectedMediaId, setSelectedMediaId] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [capturing, setCapturing] = useState(false);
  const [message, setMessage] = useState("");
  const [loadError, setLoadError] = useState("");

  const activeClip =
    (selectedClipId
      ? project.tracks.flatMap((t) => t.clips).find((c) => c.id === selectedClipId)
      : null) ?? clipAtTime(project, positionMs);

  const previewMedia = selectedMediaId
    ? findMedia(project, selectedMediaId)
    : activeClip
      ? findMedia(project, activeClip.mediaId)
      : project.media[project.media.length - 1];

  const loadPreview = useCallback(async () => {
    if (!previewMedia) {
      setPreviewUrl(null);
      setPreviewKind(null);
      return;
    }

    const blobId = previewMedia.blobId ?? previewMedia.id;
    const kind = resolvePreviewKind(previewMedia);
    const ext = extFromName(previewMedia.fileName);

    if ((ext === "heic" || ext === "heif") && kind === "image") {
      setLoadError("HEIC 格式浏览器不支持，请先转为 JPG/PNG");
      setPreviewUrl(null);
      setPreviewKind("image");
      return;
    }

    setLoadError("");
    try {
      const url = await api.getMediaUrl({ ...previewMedia, blobId });
      if (!url) {
        setLoadError("素材未找到，请重新导入");
        setPreviewUrl(null);
        return;
      }
      setPreviewUrl(url);
      setPreviewKind(kind);
    } catch (err) {
      setLoadError(String(err));
    }
  }, [previewMedia]);

  useEffect(() => {
    loadPreview();
  }, [loadPreview]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || previewKind !== "video") return;
    if (playing) {
      video.play().catch(() => setLoadError("播放失败，请使用 H.264 MP4"));
    } else {
      video.pause();
    }
  }, [playing, previewKind]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || previewKind !== "video" || playing) return;
    const target = activeClip
      ? (activeClip.trimInMs + (positionMs - activeClip.startMs)) / 1000
      : positionMs / 1000;
    if (Number.isFinite(target) && Math.abs(video.currentTime - target) > 0.15) {
      video.currentTime = Math.max(0, target);
    }
  }, [positionMs, playing, previewKind, activeClip]);

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video || !activeClip) {
      onPositionChange(Math.round((video?.currentTime ?? 0) * 1000));
      return;
    }
    onPositionChange(
      Math.round(activeClip.startMs + video.currentTime * 1000 - activeClip.trimInMs),
    );
  };

  const activeSubtitle = subtitleAtTime(project, positionMs);

  const importDesktop = async () => {
    setImporting(true);
    setMessage("");
    setLoadError("");
    try {
      const updated = await api.pickAndImportMedia(project);
      onProjectUpdate(updated);
      const lastMedia = updated.media[updated.media.length - 1];
      if (lastMedia) setSelectedMediaId(lastMedia.id);
      setMessage(`已导入 ${updated.media.length - project.media.length} 个素材`);
    } catch (err) {
      setLoadError(String(err));
    } finally {
      setImporting(false);
    }
  };

  const importFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    if (isTauriApp()) {
      await importDesktop();
      return;
    }
    setImporting(true);
    setMessage("");
    setLoadError("");
    let current = project;
    let lastAsset = null;
    try {
      for (let i = 0; i < files.length; i++) {
        const result = await api.importMediaFile(current, files[i]);
        current = result.project;
        lastAsset = result.asset;
      }
      onProjectUpdate(current);
      if (lastAsset) {
        setSelectedMediaId(lastAsset.id);
        const clips0 = current.tracks[0]?.clips ?? [];
        const lastClip = clips0[clips0.length - 1];
        if (lastClip) setSelectedClipId(lastClip.id);
      }
      setMessage(`已导入 ${files.length} 个素材`);
    } catch (err) {
      setLoadError(String(err));
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleUpdateClip = async (clipId: string, patch: Partial<Clip>) => {
    const updated = await api.updateClip(project, clipId, patch);
    onProjectUpdate(updated);
  };

  const handleDropMedia = async (mediaId: string, trackIndex: number, startMs: number) => {
    const updated = await api.addClipToTrack(project, mediaId, trackIndex, startMs);
    onProjectUpdate(updated);
    setSelectedMediaId(mediaId);
  };

  const handleRemoveClip = async (clipId: string) => {
    const updated = await api.removeClip(project, clipId);
    onProjectUpdate(updated);
    setSelectedClipId(null);
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key !== "Delete" && e.key !== "Backspace") return;
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) return;
      if (!selectedClipId) return;
      e.preventDefault();
      handleRemoveClip(selectedClipId);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [selectedClipId, project]);

  const handleAspectChange = (resolution: [number, number]) => {
    onProjectUpdate({ ...project, resolution });
  };

  const handleCaptureStill = async () => {
    const el =
      previewKind === "video"
        ? videoRef.current
        : previewKind === "image"
          ? imageRef.current
          : null;
    if (!el || !previewMedia) {
      setMessage("请先导入并预览素材");
      return;
    }
    setCapturing(true);
    setMessage("");
    try {
      const { dataUrl, palette } = await capturePreviewFrame(el);
      const still = await api.addStillFrame(
        project.id,
        previewMedia.id,
        positionMs,
        `静帧 ${formatMs(positionMs)}`,
        ["静帧"],
        palette.length ? palette : ["#5b8def", "#f59e6c", "#3dd68c"],
        dataUrl,
      );
      onProjectUpdate({ ...project, stills: [...project.stills, still] });
      setMessage("静帧已捕捉并加入静帧库");
    } catch (err) {
      setMessage(String(err));
    } finally {
      setCapturing(false);
    }
  };

  const canCapture = !!previewUrl && !loadError;

  const previewPanel = (
    <div className="relative flex h-full flex-col bg-black">
        <div className="flex items-center justify-between px-3 py-2">
          <span className="text-xs text-sc-muted">
            预览
            {previewMedia
              ? ` · ${previewMedia.name} (${resolvePreviewKind(previewMedia)})`
              : ""}
          </span>
          <div className="flex items-center gap-2">
            <AspectRatioPicker
              resolution={project.resolution}
              onChange={handleAspectChange}
            />
            <input
              ref={fileRef}
              type="file"
              multiple
              accept="video/*,image/*,audio/*,.mov,.mp4,.m4v,.mkv,.webm,.jpg,.jpeg,.png,.webp,.gif,.mp3,.wav,.m4a"
              className="hidden"
              onChange={(e) => importFiles(e.target.files)}
            />
            <button
              type="button"
              disabled={importing}
              onClick={() => (isTauriApp() ? importDesktop() : fileRef.current?.click())}
              className="flex items-center gap-1.5 rounded-lg bg-sc-accent px-3 py-1.5 text-xs text-white hover:bg-sc-accent-dim disabled:opacity-50"
            >
              <Upload size={12} />
              {importing ? "导入中…" : "导入素材"}
            </button>
          </div>
        </div>

        <div className="relative flex flex-1 items-center justify-center overflow-hidden px-4">
          <div
            className="relative flex max-h-full max-w-full items-center justify-center"
            style={{ aspectRatio: aspectCssRatio(project.resolution) }}
          >
            {previewUrl && previewKind === "video" ? (
              <video
                ref={videoRef}
                src={previewUrl}
                className="h-full w-full object-contain"
                playsInline
                preload="auto"
                onTimeUpdate={handleTimeUpdate}
                onCanPlay={() => setLoadError("")}
                onError={() => setLoadError("视频解码失败，请转为 H.264 MP4")}
                onEnded={() => onPositionChange(activeClip?.startMs ?? 0)}
              />
            ) : previewUrl && previewKind === "audio" ? (
              <div className="flex flex-col items-center justify-center gap-3 text-sc-muted">
                <Music size={48} className="opacity-40" />
                <audio src={previewUrl} controls className="w-4/5" />
                <p className="text-xs">{previewMedia?.name}</p>
              </div>
            ) : previewUrl && previewKind === "image" ? (
              <img
                ref={imageRef}
                key={previewUrl}
                src={previewUrl}
                alt={previewMedia?.name ?? "图片素材"}
                className="h-full w-full object-contain"
                onLoad={() => setLoadError("")}
                onError={() => setLoadError("图片加载失败，请用 JPG/PNG/WebP 格式")}
              />
            ) : loadError ? (
              <div className="px-4 text-center text-xs text-red-300">{loadError}</div>
            ) : (
              <div className="text-center text-sc-muted">
                <Film size={40} className="mx-auto opacity-20" />
                <p className="mt-2 text-xs">支持导入图片与视频</p>
                <div className="mt-2 flex justify-center gap-3 text-[10px]">
                  <span className="flex items-center gap-1">
                    <Video size={10} /> MP4 MOV
                  </span>
                  <span className="flex items-center gap-1">
                    <Image size={10} /> JPG PNG
                  </span>
                </div>
              </div>
            )}

            {activeSubtitle && (
              <div className="pointer-events-none absolute bottom-8 left-0 right-0 px-6 text-center">
                <span className="inline-block rounded bg-black/70 px-3 py-1.5 text-sm text-white shadow-lg">
                  {activeSubtitle.text}
                </span>
              </div>
            )}

            {canCapture && (
              <button
                type="button"
                disabled={capturing}
                onClick={handleCaptureStill}
                title="捕捉此刻静帧"
                className="absolute bottom-2 right-2 flex h-9 w-9 items-center justify-center rounded-full bg-sc-accent/90 text-white shadow-lg hover:bg-sc-accent disabled:opacity-50"
              >
                <Camera size={16} />
              </button>
            )}
          </div>
        </div>

        {message && !loadError && (
          <div className="absolute bottom-2 left-1/2 z-10 -translate-x-1/2 rounded bg-sc-panel/90 px-3 py-1 text-[10px] text-sc-muted">
            {message}
          </div>
        )}
    </div>
  );

  const workspacePanel = (
    <>
      <MediaBin
        media={project.media}
        selectedMediaId={selectedMediaId}
        onSelect={setSelectedMediaId}
      />
      <Timeline
        project={project}
        positionMs={positionMs}
        selectedClipId={selectedClipId}
        onSelectClip={setSelectedClipId}
        onSeek={onPositionChange}
        onUpdateClip={handleUpdateClip}
        onDropMedia={handleDropMedia}
        onRemoveClip={handleRemoveClip}
      />
    </>
  );

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ResizableSplit>{[previewPanel, workspacePanel]}</ResizableSplit>
    </div>
  );
}
