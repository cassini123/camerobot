declare module "onnxruntime-web";
