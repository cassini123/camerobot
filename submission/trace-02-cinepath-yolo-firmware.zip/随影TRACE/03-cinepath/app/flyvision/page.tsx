import Link from "next/link";

export default function FlyvisionModulePage() {
  return (
    <main className="landing">
      <p style={{ color: "var(--gold)", letterSpacing: "0.18em", fontSize: 12 }}>
        TRACE · FLIGHT VISION
      </p>
      <h1>飞行视觉</h1>
      <p style={{ color: "var(--muted)", maxWidth: 640, lineHeight: 1.75, fontSize: 18 }}>
        YOLOv8n 主体检测、本地相似度与偏移反馈在提交包的 04-yolo。
        浏览器工作台源码在 04-yolo/browser，按 app、components、lib、public、tests
        的原路径放回本工程后，重新运行 npm run dev，即可在此打开上传图与摄像头对照。
      </p>
      <div className="cards">
        <Link className="card" href="/yunjing/cinepath">
          <b>返回 CinePath</b>
          <p style={{ color: "var(--muted)", marginTop: 8 }}>继续预演摄影路径，导出镜头 JSON 给飞行比对。</p>
        </Link>
      </div>
    </main>
  );
}
